<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>Jalandhar</h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">Jalandhar</li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- service Sections start -->
<section class="safe_service_section">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-12">
				<a href="contact.php"><img src="images/safe-contact.webp" alt="contact images" style="width:100%;"></a>
			</div>

			<div class="col-lg-9 col-12">
				<div class="s_img_box">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d109066.25059426243!2d75.5033783672047!3d31.322525387246877!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391a5a5747a9eb91%3A0xc74b34c05aa5b4b8!2sJalandhar%2C%20Punjab!5e0!3m2!1sen!2sin!4v1658577659048!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
					<div class="s_content_1">
						<h2>Jalandhar</h2>
						<p>Our packing and moving services in Jalandhar are considered the best because of the unique and most enhanced way to execute the shifting problems. This way of providing shifting services helped us earn an excellent reputation in the shifting service industry. Not only do we hold a lot of experience in this domain, but we also hold the right equipment and the best convoy of vehicles. Considering these things, we assure you that we can assist and guide you by successfully transferring your belongings to their new destination in excellent condition. </p>

						<p>Therefore, we have become a top choice for everyone willing to shift and relocate as our services are timely and provide on-time customer services to clear your doubts. </p>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</section>



<?php include('footer.php'); ?>