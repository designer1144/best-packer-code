
<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>Contact Us</h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">Contact Us</li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- address details -->
<section class="address_details">
  <div class="container">
    <div class="row"> 
      <div class="col-lg-4">
        <div class="c_details">
          <div class="c_icon">
            <i class="fa-solid fa-location-dot"></i>
          </div>
          <p><b>Address : </b> <?php echo $address ;?></p>
        </div>
      </div>

      <div class="col-lg-4">
        <div class="c_details">
          <div class="c_icon">
            <i class="fa-solid fa-phone"></i>
          </div>
          <p><b>Mobile : </b> <?php echo $number1; ?></p>
        </div>
      </div>

      <div class="col-lg-4">
        <div class="c_details">
          <div class="c_icon">
            <i class="fa-solid fa-envelope"></i>
          </div>
          <p><b>E-Mail : </b> <?php echo $mail; ?></p>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- address details end-->

<!-- contact counter start  -->
 <section class="contact-counter">
   <div class="main_title">
      <h1><span>Get</span> In Touch</h1>
      <img src="images/divider.webp" alt="divider image">
    </div>

   <div class="container">
     <div class="row">
       <div class="col-lg-8 col-12">
         <div class="contact-box">
           <form method="post" action="#!">
             <input type="text" name="fullname" placeholder="Enter Name">
             <input type="email" name="email" placeholder="Enter Email">
             <input type="text" name="phon" placeholder="Enter Phone">
             <input type="text" name="cityfrom" placeholder="Enter From">
             <input type="text" name="cityto" placeholder="Enter To">
             <textarea name="message" placeholder="Leave Message"></textarea>
             <button value="submit">Submit</button>
           </form>
         </div>
       </div>
       <div class="col-lg-4 col-12">
         <img src="images/contact1.webp">
       </div>
     </div>
   </div>
 </section>
<!-- contact counter end  -->

<?php include('footer.php'); ?>