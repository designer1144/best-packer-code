<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>Our Gallery</h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">Our Gallery</li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>


 <!-- our gallery section start -->
<section class="safe-gallery">
  <div class="container">

     <div class="main_title">
      <h1><span>Our</span> Gallery</h1>
      <img src="images/divider.webp" alt="divider image">
    </div>

    <div class="row">
      <div class="col-lg-4 col-12">
        <div class="g_box">
          <img src="images/safe-gallery/s-gallery-1.webp" alt="gallery image">
        </div>
      </div>
      <div class="col-lg-4 col-12">
        <div class="g_box">
          <img src="images/safe-gallery/s-gallery-2.webp" alt="gallery image">
        </div>
      </div>
      <div class="col-lg-4 col-12">
        <div class="g_box">
          <img src="images/safe-gallery/s-gallery-3.webp" alt="gallery image">
        </div>
      </div>
      <div class="col-lg-4 col-12">
        <div class="g_box">
          <img src="images/safe-gallery/s-gallery-4.webp" alt="gallery image">
        </div>
      </div>
      <div class="col-lg-4 col-12">
        <div class="g_box">
          <img src="images/safe-gallery/s-gallery-5.webp" alt="gallery image">
        </div>
      </div>
      <div class="col-lg-4 col-12">
        <div class="g_box">
          <img src="images/safe-gallery/s-gallery-6.webp" alt="gallery image">
        </div>
      </div>
    </div>
  </div>
</section>



<?php include('footer.php'); ?>