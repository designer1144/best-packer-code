<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>Shela</h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">Shela</li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- service Sections start -->
<section class="safe_service_section">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-12">
				<a href="contact.php"><img src="images/safe-contact.webp" alt="contact images" style="width:100%;"></a>
				 
			</div>

			<div class="col-lg-9 col-12">
				<div class="s_img_box">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29380.798486446776!2d72.43650593706022!3d23.001738991382695!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e9bc9351b0955%3A0x1c4faa48c7957c1a!2sShela%2C%20Gujarat!5e0!3m2!1sen!2sin!4v1658574814923!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
					<div class="s_content_1">
						<h2>Shela</h2>
						<p>Best Cargo Packers and Movers in Shela leads the largest team of highly specialized professionals who are well trained to carry out all the shifting processes. We always think of new possible ways to smoothen and ease the process of shifting to make it less hassling for customers so that they acquire the greatest satisfaction. Not only do we ensure the security, but to keep it more intense, we provide a tracking system which we install in trucks or every transporting vehicle. </p>

						<p>We are considered an expert when it comes to corporate shifting and commercial moving. We are available 24 hours for our customers; you just have to visit our website and contact us for any services you want to acquire. </p>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</section>



<?php include('footer.php'); ?>