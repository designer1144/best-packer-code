<?php include('header.php'); ?>
<!-- Carousel -->
<div id="demo" class="carousel slide" data-bs-ride="carousel">

  <!-- Indicators/dots -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
  </div>
  
  <!-- The slideshow/carousel -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/safe-sliders/slide1.webp" alt="safe cargo packers" class="d-block" style="width:100%">
      <div class="carousel-caption">
        <h1>Welcome To <span>Best Cargo</span></h1>
        <h3> Packers and Movers </h3>
        <p>Best Cargo Packers and Movers is an Indian-based company providing packing and moving <br> services for several years. Since the time </p>
        <br>
        <div class="btn-box">
          <a href="about-us.php">Read More. <i class="fa-solid fa-angles-right"></i> </a>
          <a href="contact.php" class="btn_contact">Contact us <i class="fa-solid fa-angles-right"></i> </a>
        </div>
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/safe-sliders/slide1.webp" alt="safe cargo packers" class="d-block" style="width:100%">
      <div class="carousel-caption">
        <h1>Welcome To <span>Best Cargo</span></h1>
        <h3> Packers and Movers </h3>
        <p>Best Cargo Packers and Movers is an Indian-based company providing packing and moving <br> services for several years. Since the time </p>
        <br>
        <div class="btn-box">
          <a href="about-us.php">Read More. <i class="fa-solid fa-angles-right"></i> </a>
          <a href="contact.php" class="btn_contact">Contact us <i class="fa-solid fa-angles-right"></i> </a>
        </div>
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/safe-sliders/slide1.webp" alt="safe cargo packers" class="d-block" style="width:100%">
      <div class="carousel-caption">
        <h1>Welcome To <span>Best Cargo</span></h1>
        <h3> Packers and Movers </h3>
        <p>Best Cargo Packers and Movers is an Indian-based company providing packing and moving <br> services for several years. Since the time </p>
        <br>
        <div class="btn-box">
          <a href="about-us.php">Read More. <i class="fa-solid fa-angles-right"></i> </a>
          <a href="contact.php" class="btn_contact">Contact us <i class="fa-solid fa-angles-right"></i> </a>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>


<!-- Process section start -->
<section class="safe_process">
  <div class="container">
    <div class="row">


      <div class="col-lg-4 col-12">
        <div class="s_process">
          <div class="p_icon">
            <i class="fa-solid fa-boxes-packing"></i>
          </div>
          <div class="p_content">
            <h2>Packing</h2>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-12">
        <div class="s_process sprocess2">
          <div class="p_icon2">
            <i class="fa-solid fa-truck-arrow-right"></i>
          </div>
          <div class="p_content2">
            <h2>Moving</h2>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-12">
        <div class="s_process">
          <div class="p_icon">
            <i class="fa-solid fa-dolly"></i>
          </div>
          <div class="p_content">
            <h2>Delivering</h2>
          </div>
        </div>
      </div>


    </div>
  </div>
</section>
<div class="clearfix"></div>

<!-- About Sections start -->
<section class="safe_about_section">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-12">
        <div class="about_content">
          <span>ABOUT <b>US</b></span>
          <h1>Company Info..</h1>
          <p><b>Best Cargo Packers and Movers</b> is an Indian-based company providing packing and moving services for several years. Since the time of the establishment of our company, we are constantly dealing with our customers' shifting and relocation problems. Providing professional shifting and moving services across India makes the transfer process hassle-free and uninterrupted. </p>
          <p>We look after all needs and requirements of our customers and provide them with a new and innovative approach to shift and relocate to new designation with ease and without bearing any damage. </p>
          <ul>
            <li><i class="fa-solid fa-check"></i> House Shifting</li>
            <li><i class="fa-solid fa-check"></i> Office Shifting</li>
            <li><i class="fa-solid fa-check"></i> Car & Bike Transportation</li>
            <li><i class="fa-solid fa-check"></i> Warehouse Shifting</li>
            <li><i class="fa-solid fa-check"></i> Local Shifting</li>
          </ul>
          <a href="about-us.php" class="btn_one1">Read More. <i class="fa-solid fa-angles-right"></i> </a>
        </div>
      </div>
      <div class="col-lg-6 col-12">
        <div class="about_img">
          <img src="images/safe-about/about-img1.webp" alt="about images">
        </div>
      </div>
    </div>
  </div>
</section>


<!-- our services section start -->
<section class="safe_services_section">
  <div class="container">
    <div class="main_title">
      <h1><span>Our</span> Services</h1>
      <img src="images/divider.webp" alt="divider image">
    </div>
    <div class="row">

      <div class="col-lg-4 col-12">
        <div class="ser_content">
          <div class="ser_icon">
            <i class="fa-solid fa-house"></i>
          </div>
          <h3>House shifting</h3>
          <p>Yes, we know how thrilling it is to move to a new house. But, there is also an utter sadness that occurs because you are leaving behind your memories. </p>
        <a href="house-shifting.php">Read More..</a>
        </div>
      </div>

      <div class="col-lg-4 col-12">
        <div class="ser_content">
          <div class="ser_icon">
           <i class="fa-solid fa-building-circle-arrow-right"></i>
          </div>
          <h3>Office shifting</h3>
          <p>We have not earned our reputation just by promising hassle-free and satisfactory services but by keeping up to them. We are renowned for our</p>
           <a href="office-shifting.php">Read More..</a>
        </div>
      </div>

<div class="col-lg-4 col-12">
        <div class="ser_content">
          <div class="ser_icon">
         <i class="fa-solid fa-warehouse"></i>
          </div>
          <h3>Warehouse Shifting</h3>
          <p>Best Cargo Packers and Movers also specialize in warehouse shifting services. We provide top-notch and professional</p>
           <a href="warehouse-shifting.php">Read More..</a>
        </div>
      </div>




      <div class="col-lg-6 col-12">
        <div class="ser_content">
          <div class="ser_icon">
          <i class="fa-solid fa-car-side"></i>
          </div>
          <h3>Car & Bike transportation</h3>
          <p>Best Cargo Packers and Movers is not about only shifting and relocating houses and offices. </p>
           <a href="car-and-bike-transportation.php">Read More..</a>
        </div>
      </div>


      <div class="col-lg-6 col-12">
        <div class="ser_content">
          <div class="ser_icon">
          <i class="fa-solid fa-truck"></i>
          </div>
          <h3>Local Shifting</h3>
          <p>With years of experience and expertise in packing and moving, we are well aware of all the customers' requirements. </p>
           <a href="local-shifting.php">Read More..</a>
        </div>
      </div>

    </div>
  </div>
</section>


<!-- welcome section Best Cargo Packers and Movers  -->

<section class="safe-welcome-1">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-12">
        <div class="welcome-content">
          <h1>Welcome To <span>Safe Cargo</span> Packers and Movers</h1>
          <p>Best Cargo Packers and Movers is an Indian-based company providing packing and moving services <br> for several years. Since the time of the establishment of our company, </p>
          <a href="contact.php" class="btn_one1">Contact Us <i class="fa-solid fa-angles-right"></i> </a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- our gallery section start -->
<section class="safe-gallery">
  <div class="container">

     <div class="main_title">
      <h1><span>Our</span> Gallery</h1>
      <img src="images/divider.webp" alt="divider image">
    </div>

    <div class="row">
      <div class="col-lg-4 col-12">
        <div class="g_box">
          <img src="images/safe-gallery/s-gallery-1.webp" alt="gallery image">
        </div>
      </div>
      <div class="col-lg-4 col-12">
        <div class="g_box">
          <img src="images/safe-gallery/s-gallery-2.webp" alt="gallery image">
        </div>
      </div>
      <div class="col-lg-4 col-12">
        <div class="g_box">
          <img src="images/safe-gallery/s-gallery-3.webp" alt="gallery image">
        </div>
      </div>
      <div class="col-lg-4 col-12">
        <div class="g_box">
          <img src="images/safe-gallery/s-gallery-4.webp" alt="gallery image">
        </div>
      </div>
      <div class="col-lg-4 col-12">
        <div class="g_box">
          <img src="images/safe-gallery/s-gallery-5.webp" alt="gallery image">
        </div>
      </div>
      <div class="col-lg-4 col-12">
        <div class="g_box">
          <img src="images/safe-gallery/s-gallery-6.webp" alt="gallery image">
        </div>
      </div>
    </div>
  </div>
</section>

<!-- city location -->
<section class="loca_list">
  <div class="container">

    <div class="main_title">
      <h1><span>Ahmedabad</span> Locations </h1>
      <img src="images/divider.webp" alt="divider image">
    </div>

    <div class="row">
      <div class="col-lg-3 col-12">
        <ul>
<li><a href="packers-and-movers-in-gota.php">Packers and Movers in Gota</a></li>
          <li><a href="packers-and-movers-in-bhopal.php">Packers and Movers in Bhopal</a></li>
          <li><a href="packers-and-movers-in-chandkheda.php">Packers and Movers in Chandkheda</a></li>
          <li><a href="packers-and-movers-in-science-city.php">Packers and Movers in Science City</a></li>
        
        </ul>
      </div>

      <div class="col-lg-3 col-12">
        <ul>
          <li><a href="packers-and-movers-in-godrej-garden-city.php">Packers and Movers in Godrej Garden City</a></li>
          <li><a href="packers-and-movers-in-shela.php">Packers and Movers in Shela</a></li>
          <li><a href="packers-and-movers-in-shahibaug.php">Packers and Movers in Shahibaug</a></li>
          <li><a href="packers-and-movers-in-ahmedabad-cantt .php">Packers and Movers in Ahmedabad Cantt </a></li>

        </ul>
      </div>

      <div class="col-lg-3 col-12">
        <ul> 
        <li><a href="packers-and-movers-in-air-force-station.php">Packers and Movers in Air Force Station</a></li>
          <li><a href="packers-and-movers-in-ahmedabad.php">Packers and Movers in Ahmedabad</a></li>
          <li><a href="packers-and-movers-in-anand.php">Packers and Movers in Anand</a></li>
          <li><a href="packers-and-movers-in-south-bopal.php">Packers and Movers in South Bopal</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-12">
        <ul> 
          <li><a href="packers-and-movers-in-gandhi-nagar.php">Packers and Movers in Gandhi Nagar</a></li>
          <li><a href="packers-and-movers-in-maninagar.php">Packers and Movers in Maninagar</a></li>
          <li><a href="packers-and-movers-in-sanand.php">Packers and Movers in Sanand</a></li>

        </ul>
      </div>

    </div>
  </div>  
</section> <br><br>
<div class="clearfix"></div>
<!-- ahmedabad locations -->

<section class="loca_list">
  <div class="container">

    <div class="main_title">
       <h1><span>City</span> Locations</h1>
      <img src="images/divider.webp" alt="divider image">
    </div>

    <div class="row">

      <div class="col-lg-3 col-12">
        <ul>
<li><a href="packers-and-movers-in-south-bopal.php">Packers and Movers in South Bopal</a></li>
          <li><a href="packers-and-movers-in-meerut.php">Packers and Movers in Meerut</a></li>
          <li><a href="packers-and-movers-in-muzaffarnagar.php">Packers and Movers in Muzaffarnagar</a></li>
          <li><a href="packers-and-movers-in-indore.php">Packers and Movers in Indore</a></li>
          <li><a href="packers-and-movers-in-jaipur.php">Packers and Movers in Jaipur</a></li>
          <li><a href="packers-and-movers-in-jalandhar.php">Packers and Movers in Jalandhar</a></li>
          <li><a href="packers-and-movers-in-kanpur.php">Packers and Movers in Kanpur</a></li>
          <li><a href="packers-and-movers-in-kolkata.php">Packers and Movers in Kolkata</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-12">
        <ul>
          <li><a href="packers-and-movers-in-lucknow.php">Packers and Movers in Lucknow </a></li>
          <li><a href="packers-and-movers-in-dehradoon.php">Packers and Movers in Dehradoon</a></li>
          <li><a href="packers-and-movers-in-goa.php">Packers and Movers in Goa</a></li>
          <li><a href="packers-and-movers-in-gorakhpur.php">Packers and Movers in Gorakhpur</a></li>
          <li><a href="packers-and-movers-in-guwahati.php">Packers and Movers in Guwahati</a></li>
          <li><a href="packers-and-movers-in-bangalore.php">Packers and Movers in Bangalore</a></li>
          <li><a href="packers-and-movers-in-gurgaon.php">Packers and Movers in Gurgaon</a></li>
        
        </ul>
      </div>


      <div class="col-lg-3 col-12">
        <ul>
          <li><a href="packers-and-movers-in-mumbai.php">Packers and Movers in Mumbai</a></li>
          <li><a href="packers-and-movers-in-hisar.php">Packers and Movers in Hisar</a></li>
          <li><a href="packers-and-movers-in-hyderabad.php">Packers and Movers in Hyderabad</a></li>
          <li><a href="packers-and-movers-in-ahmedabad.php">Packers and Movers in Ahmedabad</a></li>
          <li><a href="packers-and-movers-in-bhopal.php">Packers and Movers in Bhopal</a></li>
          <li><a href="packers-and-movers-in-bareilly.php">Packers and Movers in Bareilly</a></li>
          <li><a href="packers-and-movers-in-chandigarh.php">Packers and Movers in Chandigarh</a></li>
        </ul>
      </div>


      <div class="col-lg-3 col-12">
        <ul>
          <li><a href="packers-and-movers-in-chennai.php">Packers and Movers in Chennai</a></li>
          <li><a href="packers-and-movers-in-delhi.php">Packers and Movers in Delhi</a></li>
          <li><a href="packers-and-movers-in-surat.php">Packers and Movers in Surat</a></li>
          <li><a href="packers-and-movers-in-agra.php">Packers and Movers in Agra</a></li>
          <li><a href="packers-and-movers-in-nagpur.php">Packers and Movers in Nagpur</a></li>
          <li><a href="packers-and-movers-in-pune.php">Packers and Movers in Pune</a></li>
          <li><a href="packers-and-movers-in-raipur.php">Packers and Movers in Raipur</a></li>
        </ul>
      </div>

    </div>
  </div>  
</section>




<?php include('footer.php'); ?>