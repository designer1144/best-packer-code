<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>Bareilly </h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">Bareilly </li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- service Sections start -->
<section class="safe_service_section">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-12">
				<a href="contact.php"><img src="images/safe-contact.webp" alt="contact images" style="width:100%;"></a>
			</div>

			<div class="col-lg-9 col-12">
				<div class="s_img_box">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d112333.61782257323!2d79.35189883649939!3d28.376211940879568!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39a007334d02998d%3A0x5b9d44cf31ee87f!2sBareilly%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1658579432477!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
					<div class="s_content_1">
						<h2>Bareilly </h2>
						<p>Best Cargo Packers and Movers Bareilly is admired globally for its out-class shifting services covering almost all of the country. It is just because of the willpower and dedication of our clients that we have reached this height in the packing and moving industry. We provide top-quality services that have made us the leading packers and movers in Bareilly. Our experienced professionals provide you assistance and guidance in various services like Bike and Car transportation, corporate shifting, home shifting, domestic shifting, and local shifting. </p>

						<p>We cover almost all the country's major destinations where we are actively offering door-to-door transportation. We customize our services according to our precious customer's requirements, and that too by keeping the budget in mind. </p>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</section>



<?php include('footer.php'); ?>