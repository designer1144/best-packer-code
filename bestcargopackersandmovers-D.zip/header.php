<?php 

  $number1 = '+91 93509 59213';
  $numbertel1 = 'tel:9350959213';

  $mail = 'info@bestcargopackersandmovers.com';
  $address = 'Office No. 19, Near Seal Petrol Pump Aslali Bareja, Highway, near Kanchan Farmhouse, Ahmedabad, Gujarat 382427.';

 ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Best Cargo Packers and Movers in Ahmedabad | Call :+91 93509 59213</title>
    <meta name="description" content="Packers and Movers in Ahmedabad, Best Cargo Packers Movers in Ahmedabad offers the dynamic range of Packers Movers in Ahmedabad, ">
    <meta name="keywords" content="packers and movers ahmedabad, movers and packers ahmedabad, Ahmedabad">
    <meta name="author" content="Best Cargo Packers and Movers">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="icon" type="image/png" href="images/favicon.webp" sizes="16x16">
    <link rel="stylesheet" type="text/css" href="css/style.css">

    
  </head>
  <body>

    <div class="main_topbar_scroll">
          <marquee behavior="scroll" direction="left" scrollamount="6" scrolldelay="10" onmouseover="this.stop();" onmouseout="this.start();">Welcome To Best Cargo Packers and Movers. We are Provided All type Services In Any Area. Contact Us With Given Helpline Number(+91 9350959213) .
          </marquee>
    </div>

<!-- topheader section design -->
    <section class="topbar_section">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-12">
           <div class="contt_details">
             <ul>
               <li><a href="<?php echo $numbertel1; ?>"><i class="fa-solid fa-phone"></i> <?php echo $number1; ?></a></li>
               <li><a href="mailto:<?php echo $mail; ?>"><i class="fa-solid fa-envelope"></i> <?php echo $mail; ?></a></li>
             </ul>
           </div>
          </div>
           <div class="col-lg-2 col-12">
             <div class="social_media_i">
               <ul>
                 <li><a href="#!"><i class="fa-brands fa-facebook-f"></i></a></li>
                 <li><a href="#!"><i class="fa-brands fa-twitter"></i></a></li>
                 <li><a href="#!"><i class="fa-brands fa-linkedin-in"></i></a></li>
                 <li><a href="#!"><i class="fa-brands fa-instagram"></i></a></li>
               </ul>
             </div>
           </div>
            <div class="col-lg-2 col-12">
                  <a href="contact.php" class="btn-primary1">Get a Quote</a>
            </div>
        </div>
      </div>
    </section>



    <!-- navbar design -->

<nav>
  <div class="logo_design">
    <a href="index.php"><img src="images/logo.webp" alt="header logo design"></a>
  </div>

  <!-- toggle bar icon -->
<div class="container9" onclick="myFunction(this)">
  <div class="bar1"></div>
  <div class="bar2"></div>
  <div class="bar3"></div>
</div>

<ul class="menu_design">
      <li><a href="index.php">Home</a></li>
      <li><a href="about-us.php">About Us</a></li>

      <li class="s_drop_list"><a href="#!">Services <i class="fa-solid fa-angle-down"></i> </a>
        <ul class="drop_list">
          <li><a href="house-shifting.php">House shifting</a></li>
          <li><a href="office-shifting.php">Office shifting</a></li>
          <li><a href="car-and-bike-transportation.php">Car & Bike transportation</a></li>
          <li><a href="warehouse-shifting.php">Warehouse Shifting</a></li>
          <li><a href="local-shifting.php">Local Shifting</a></li>
        </ul>
      </li>

      <li><a href="gallery.php">Gallery</a></li>

      <li class="s_drop_list"><a href="#!">Locations <i class="fa-solid fa-angle-down"></i> </a>
        <ul class="drop_list scroll_down_l">
          <li><a href="packers-and-movers-in-gota.php">Gota</a></li>
          <li><a href="packers-and-movers-in-bhopal.php">Bhopal</a></li>
          <li><a href="packers-and-movers-in-chandkheda.php">Chandkheda</a></li>
          <li><a href="packers-and-movers-in-science-city.php">Science City</a></li>
          <li><a href="packers-and-movers-in-godrej-garden-city.php">Godrej Garden City</a></li>
          <li><a href="packers-and-movers-in-shela.php">Shela</a></li>
          <li><a href="packers-and-movers-in-shahibaug.php">Shahibaug</a></li>
          <li><a href="packers-and-movers-in-ahmedabad-cantt .php">Ahmedabad Cantt </a></li>
          <li><a href="packers-and-movers-in-air-force-station.php">Air Force Station</a></li>
          <li><a href="packers-and-movers-in-ahmedabad.php">Ahmedabad</a></li>
          <li><a href="packers-and-movers-in-anand.php">Anand</a></li>
          <li><a href="packers-and-movers-in-south-bopal.php">South Bopal</a></li>
          <li><a href="packers-and-movers-in-gandhi-nagar.php">Gandhi Nagar</a></li>
          <li><a href="packers-and-movers-in-maninagar.php">Maninagar</a></li>
          <li><a href="packers-and-movers-in-sanand.php">Sanand</a></li>
          <li><a href="packers-and-movers-in-meerut.php">Meerut</a></li>
          <li><a href="packers-and-movers-in-muzaffarnagar.php">Muzaffarnagar</a></li>
          <li><a href="packers-and-movers-in-indore.php">Indore</a></li>
          <li><a href="packers-and-movers-in-jaipur.php">Jaipur</a></li>
          <li><a href="packers-and-movers-in-jalandhar.php">Jalandhar</a></li>
          <li><a href="packers-and-movers-in-kanpur.php">Kanpur</a></li>
          <li><a href="packers-and-movers-in-kolkata.php">Kolkata</a></li>
          <li><a href="packers-and-movers-in-lucknow.php">Lucknow </a></li>
          <li><a href="packers-and-movers-in-dehradoon.php">Dehradoon</a></li>
          <li><a href="packers-and-movers-in-goa.php">Goa</a></li>
          <li><a href="packers-and-movers-in-gorakhpur.php">Gorakhpur</a></li>
          <li><a href="packers-and-movers-in-guwahati.php">Guwahati</a></li>
          <li><a href="packers-and-movers-in-bangalore.php">Bangalore</a></li>
          <li><a href="packers-and-movers-in-gurgaon.php">Gurgaon</a></li>
          <li><a href="packers-and-movers-in-mumbai.php">Mumbai</a></li>
          <li><a href="packers-and-movers-in-hisar.php">Hisar</a></li>
          <li><a href="packers-and-movers-in-hyderabad.php">Hyderabad</a></li>
          <li><a href="packers-and-movers-in-ahmedabad.php">Ahmedabad</a></li>
          <li><a href="packers-and-movers-in-bhopal.php">Bhopal</a></li>
          <li><a href="packers-and-movers-in-bareilly.php">Bareilly</a></li>
          <li><a href="packers-and-movers-in-chandigarh.php">Chandigarh</a></li>
          <li><a href="packers-and-movers-in-chennai.php">Chennai</a></li>
          <li><a href="packers-and-movers-in-delhi.php">Delhi</a></li>
          <li><a href="packers-and-movers-in-surat.php">Surat</a></li>
          <li><a href="packers-and-movers-in-agra.php">Agra</a></li>
          <li><a href="packers-and-movers-in-nagpur.php">Nagpur</a></li>
          <li><a href="packers-and-movers-in-pune.php">Pune</a></li>
          <li><a href="packers-and-movers-in-raipur.php">Raipur</a></li>
        </ul>
      </li>

      <li><a href="contact.php">Contact Us</a></li>
</ul>

</nav>


<div class="fixed_call_whatsapp">
  <ul>
    <li><a href="tel:9350959213"><img src="images/calling-i.webp"></a></li>
    <li><a href="https://api.whatsapp.com/send?phone=919350959213"><img src="images/whatsapp-i.webp"></a></li>
  </ul>
</div>

