<!-- footer design section start -->
<section class="safe-footer">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
        <img src="images/footer_logo.webp" alt="footer logo image"> <br><br>
        <p>Best Cargo Packers and Movers is an Indian-based company providing packing and moving services for several years. Since the time of the establishment of our company, we are constantly dealing with our customers' </p>
        <a href="about-us.php" class="btn_one1">Read More. <i class="fa-solid fa-angles-right"></i></a>
      </div>

      <div class="col-lg-2 col-12">
        <div class="f_title">
          <h4>Quick Links</h4>
        </div>
        <ul class="f_list1">
          <li><a href="index.php">Home</a></li>
          <li><a href="about-us.php">About Us</a></li>
          <li><a href="gallery.php">Our Gallery</a></li>
          <li><a href="contact.php">Contact Us</a></li>
        </ul>
      </div>

      <div class="col-lg-2 col-12">
        <div class="f_title">
          <h4>Our Services</h4>
        </div>
        <ul class="f_list1">
          <li><a href="house-shifting.php">House Shifting</a></li>
          <li><a href="office-shifting.php">Office Shifting</a></li>
          <li><a href="car-and-bike-transportation.php">Car and Bike Transportation</a></li>
          <li><a href="warehouse-shifting.php">Warehouse Shifting</a></li>
          <li><a href="local-shifting.php">Local Shifting</a></li>
        </ul>
      </div>

      <div class="col-lg-4 col-12">
        <div class="f_title">
          <h4>Contact Details</h4>
        </div>
         <ul>
           <li><i class="fa-solid fa-location-dot"></i> <b>Address : </b> <?php echo $address; ?>  </li> <br>
           <li><i class="fa-solid fa-location-dot"></i> <b>Mobile : </b> <?php echo $number1; ?>  </li><br>
           <li><i class="fa-solid fa-location-dot"></i> <b>Mail : </b> <?php echo $mail; ?>  </li>
         </ul>
      </div>


    </div>
  </div>
</section>

<section class="copyritht_section">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-12">
        <p>2022-23 All right Reserved <a href="#!"> <i>Best Cargo Packers and Movers</i></a></p>
      </div>
    </div>
  </div>
</section>


<script
  src="https://code.jquery.com/jquery-3.6.0.js"
  integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
  crossorigin="anonymous"></script>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <script>
function myFunction(x) {
  x.classList.toggle("change");
}
</script>

<script type="text/javascript">
  $(document).ready(function(){
      $(".container9").click(function(){
        $(".menu_design").slideToggle();
      });
  });
</script>

  </body>
</html>