<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>About Us</h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">About Us</li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- About Sections start -->
<section class="safe_about_section">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-12">
        <div class="about_content">
          <span>ABOUT <b>US</b></span>
          <h1>Company Info..</h1>
          <p><b>Best Cargo Packers and Movers</b> is an Indian-based company providing packing and moving services for several years. Since the time of the establishment of our company, we are constantly dealing with our customers' shifting and relocation problems. Providing professional shifting and moving services across India makes the transfer process hassle-free and uninterrupted. We look after all needs and requirements of our customers and provide them with a new and innovative approach to shift and relocate to new designation with ease and without bearing any damage. </p>

          <p>There is no doubt that the transfer of goods and belongings to a new place is quite challenging and time-consuming and requires utmost accuracy to deal with. That is why our Packers and Movers deal with all types of packing and moving problems with the help of expert staff across India.  <br>
Connect to us today for the following services:
</p>
          <ul>
            <li><i class="fa-solid fa-check"></i> House Shifting</li>
            <li><i class="fa-solid fa-check"></i> Office Shifting</li>
            <li><i class="fa-solid fa-check"></i> Car & Bike Transportation</li>
            <li><i class="fa-solid fa-check"></i> Warehouse Shifting</li>
            <li><i class="fa-solid fa-check"></i> Local Shifting</li>
          </ul>
        </div>
      </div>
      <div class="col-lg-6 col-12">
        <div class="about_img">
          <img src="images/safe-about/about-img2.webp" alt="about images">
        </div>
      </div>
    </div>
  </div>
</section>



<?php include('footer.php'); ?>