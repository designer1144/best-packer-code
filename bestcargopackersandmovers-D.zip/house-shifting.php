<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>House shifting</h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">House shifting</li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- service Sections start -->
<section class="safe_service_section">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-12">
				<h2>All Services</h2>
				<ul>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> House Shifting</a></li>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> House Shifting</a></li>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> House Shifting</a></li>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> House Shifting</a></li>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> House Shifting</a></li>
				</ul>
			</div>

			<div class="col-lg-9 col-12">
				<div class="s_img_box">
					<img src="images/safe-services/house.webp" alt="service image">
					<div class="s_content_1">
						<h2>House Shifting</h2>
						<p>Yes, we know how thrilling it is to move to a new house. But, there is also an utter sadness that occurs because you are leaving behind your memories. Shifting consumes time to adjust and settle in a new place, and so much to carry and shift makes it even harder to cover up. And that's where Best Cargo Packers and Movers enter. We offer you the smoothest and uninterrupted shifting and relocation services which will make you forget that you moved to a new place. </p>

						<p>Our professionals will help you settle in a new place with complete peace of mind and ease that will not hinder your business or time. We are well-known for our timely and precise services, which are the main reason for our customers' utmost satisfaction. </p>
						
					</div>
				</div>
			</div>

		</div>
	</div>
</section>



<?php include('footer.php'); ?>