<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>Local Shifting</h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">Local Shifting</li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- service Sections start -->
<section class="safe_service_section">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-12">
				<h2>All Services</h2>
				<ul>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> Local Shifting</a></li>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> Local Shifting</a></li>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> Local Shifting</a></li>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> Local Shifting</a></li>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> Local Shifting</a></li>
				</ul>
			</div>

			<div class="col-lg-9 col-12">
				<div class="s_img_box">
					<img src="images/safe-services/local.webp" alt="service image">
					<div class="s_content_1">
						<h2>Local Shifting</h2>
						<p>With years of experience and expertise in packing and moving, we are well aware of all the customers' requirements. No doubt, a single man can never accomplish the task of local Shifting by himself; that is why Best Cargo Packers and Movers are ready to assist and guide you throughout the process. We offer hassle-free home shifting and relocation locally. </p>

						<p><b>Best Cargo Packers and Movers</b> is an ISO-certified packing and moving company that aims to provide you with the best home shifting, office relocation, Car & Bike transportation, and local shifting services. Our customers acquire overall guidance during a shifting process that includes packing the first item at the current residence to unpacking the item at the new destination.</p>

					</div>
				</div>
			</div>

		</div>
	</div>
</section>



<?php include('footer.php'); ?>