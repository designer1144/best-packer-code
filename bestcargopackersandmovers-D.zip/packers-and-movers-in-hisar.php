<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>Hisar </h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">Hisar </li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- service Sections start -->
<section class="safe_service_section">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-12">
				<a href="contact.php"><img src="images/safe-contact.webp" alt="contact images" style="width:100%;"></a>
			</div>

			<div class="col-lg-9 col-12">
				<div class="s_img_box">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d111497.06572062414!2d75.68549800706063!3d29.15632270313097!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391232d8011d0c37%3A0x1d3f0df105af1178!2sHisar%2C%20Haryana!5e0!3m2!1sen!2sin!4v1658578898219!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
					<div class="s_content_1">
						<h2>Hisar </h2>
						<p>There is a huge majority of people who believes in our services. We, "Best Cargo Packers and Movers, are known to be the most specialized and top-class services provider in Hisar. With the help of the excellent and experienced staff, we can stand on our customer's hope of acquiring the most satisfying shifting and relocating experience. While shifting, we supervise goods' external and internal flow to avoid unfortunate circumstances that might lead to damage. </p>

						<p>Our services are easy and reasonable to book as we shift everything from cars, furniture, households, and corporate goods from our current location to the new required destination timely and without hassle. Explore more about our services and contact us today.</p>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</section>



<?php include('footer.php'); ?>