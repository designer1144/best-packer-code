<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>Office shifting</h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">Office shifting</li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- service Sections start -->
<section class="safe_service_section">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-12">
				<h2>All Services</h2>
				<ul>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> Office shifting</a></li>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> Office shifting</a></li>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> Office shifting</a></li>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> Office shifting</a></li>
					<li><a href="#!"><i class="fa-solid fa-circle-arrow-right"></i> Office shifting</a></li>
				</ul>
			</div>

			<div class="col-lg-9 col-12">
				<div class="s_img_box">
					<img src="images/safe-services/office.webp" alt="service image">
					<div class="s_content_1">
						<h2>Office shifting</h2>
						<p>We have not earned our reputation just by promising hassle-free and satisfactory services but by keeping up to them. We are renowned for our office shifting across the nation. We provide full assistance and guidance to organizations by helping them relocate and shift their offices to their required destinations. We provide these shifting services in any part of the nation, even on an international level. </p>

						<p>As we very well keep track of time and always provide timely services, we ensure to execute the office shifting process in a planned manner. Furthermore, we carefully handle the goods and belongings and appropriately pack them to avoid damaging them. Over the ages, we have successfully aided several big and small organizations with our shifting services. </p>
						
					</div>
				</div>
			</div>

		</div>
	</div>
</section>



<?php include('footer.php'); ?>