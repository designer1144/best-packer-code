<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>Surat </h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">Surat </li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- service Sections start -->
<section class="safe_service_section">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-12">
				<a href="contact.php"><img src="images/safe-contact.webp" alt="contact images" style="width:100%;"></a>
			</div>

			<div class="col-lg-9 col-12">
				<div class="s_img_box">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d238132.63727384948!2d72.68220738859044!3d21.15946270544973!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04e59411d1563%3A0xfe4558290938b042!2sSurat%2C%20Gujarat!5e0!3m2!1sen!2sin!4v1658580628150!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
					<div class="s_content_1">
						<h2>Surat </h2>
						<p>Best Cargo Packers and Movers Surat provides services at the most affordable prices and several benefits to its customers. We use quality packaging material to avoid even a small type of scratch while loading, transportation, unloading, and unpacking. We are equipped with the necessary means of transport to carry your belongings in every way possible. </p>

						<p>Our trucks and carriers are driven by highly specialized professionals responsible for moving your highly expensive houses, goods, and any kind of belongings. If you need to store your asset with us at any time, you can rest assured as we provide stockpiling compartments that keep your stuff safe and secured. </p>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</section>



<?php include('footer.php'); ?>