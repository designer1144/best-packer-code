<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>Muzaffarnagar</h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">Muzaffarnagar</li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- service Sections start -->
<section class="safe_service_section">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-12">
				<a href="contact.php"><img src="images/safe-contact.webp" alt="contact images" style="width:100%;"></a>
			</div>

			<div class="col-lg-9 col-12">
				<div class="s_img_box">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d55574.58101935486!2d77.67383810658946!3d29.475195838783222!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390c1ba00983523d%3A0xc6a75ba008574871!2sMuzaffarnagar%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1658577342925!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
					<div class="s_content_1">
						<h2>Muzaffarnagar</h2>
						<p>Best Cargo Packers and Movers in Muzaffarnagar follow the idea of safe and secure transportation by heart. Providing customers services filled with excellence is our prime focus. We know that timely transportation of goods and services is always a matter of concern for you, but we assure you to we will convey your belongings to you at the scheduled time. </p>

						<p>To outperform other competitors in the packing and moving industry Best Cargo Packers and Movers work according to certain principles that helps us provide acute services to our clients and to fulfil their requirements and needs regarding shifting. To hire our professionals to assist and guide you, just get in touch with us by visiting our website.</p>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</section>



<?php include('footer.php'); ?>