<?php include('header.php'); ?>

<section class="breadcrumb_1">
	<div class="container">

		<h2>Science City</h2>

		<div class="row">
			<div class="col-lg-12 col-12">
				<div aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-item-home">Home</a></li>
				    <li class="breadcrumb-item">Science City</li>
				  </ol>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- service Sections start -->
<section class="safe_service_section">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-12">
				<a href="contact.php"><img src="images/safe-contact.webp" alt="contact images" style="width:100%;"></a>
				
			</div>

			<div class="col-lg-9 col-12">
				<div class="s_img_box">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3670.3949032762157!2d72.49307291428363!3d23.08263541987454!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e9d28b72e6a1f%3A0xcce2a5c6361b68e8!2sScience%20City!5e0!3m2!1sen!2sin!4v1658574066976!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
					<div class="s_content_1">
						<h2>Science City</h2>
						<p>Best Cargo Packers and Movers is a remarkable shifting service provider in Science City. We know you can feel the need for transportation at any time, and this is true that you cannot carry out the shifting process all by yourself. You must look for the most trusted and reliable packing and moving company. But you should be cautious while choosing the best transporters in Science City. </p>

						<p>We are proud to claim that Best Cargo Packers and Movers are renowned packers and movers in India that have been successfully assisting and guiding their customers for several years. We assure you to provide you with the most secure, timely, and safe travel with the help of our professionals.</p>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</section>



<?php include('footer.php'); ?>